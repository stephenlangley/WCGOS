﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using System.IO;


namespace WPM
{
    class Program
    {
        static void Main(string[] args)
        {
            String batchID = "";
            String wpmPath = "";
            String wpmOutputPath = "";
            // Don't forget to check the NAME of the EXECUTABLE before building.
            // change doManual to false if we are auto downloading and auto processing todays file.
            Boolean doManual = true;  // change this to false if creating the auto exe.
            //get the latest downloads from WPM ===============================================================================
            if (doManual) wpmPath = ".\\WPM_Files\\"; // change this path to the actual finance path or leave blank for the same path as the executable.
            if (doManual) wpmOutputPath = ".\\OutputFiles\\"; // change this path to the actual finance path or leave blank for the same path as the executable.
            //use these PATHS to be used if creating Auto exe. Because the scheduler will create the folders in c:\windows\sysWow64
            if (!doManual) wpmPath = "C:\\Program Files (x86)\\Agresso 5.7.1\\Data Files\\agrLive\\wpm\\WPM_Files\\"; // change this path to the actual finance path or leave blank for the same path as the executable.
            if (!doManual) wpmOutputPath = "C:\\Program Files (x86) \\Agresso 5.7.1\\Data Files\\agrLive\\wpm\\OutputFiles\\"; // change this path to the actual finance path or leave blank for the same path as the executable.
            
            try
            {
                if (!Directory.Exists(wpmPath))
                {
                    Directory.CreateDirectory(wpmPath);//note CreateDirectory does nothing if the directory exists 
                }                                      // so the Directory.Exists is redundant and we can remove this test if we want to. 
                if (!Directory.Exists(wpmOutputPath))
                {
                    Directory.CreateDirectory(wpmOutputPath);
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.ToString()); }
                        
            ftp ftpClient = new ftp(@" ftp://uk-ftp-1.wpmeducation.com", "WAR0127-01_store_edu_wpmhost_net_download", "yvn?ncLXfK--eO#7");
            string[] simpleDirectoryListing = ftpClient.directoryListSimple("data_export");// get downloads from the data_export directory
            for (int i = 0; i < simpleDirectoryListing.Count(); i++)
            {
                if (!File.Exists(wpmPath + simpleDirectoryListing[i]) && simpleDirectoryListing[i].Length > 0)// if the file does not exist locally and the filename is greater than zero
                {
                    // then download file
                    ftpClient.download("data_export/" + simpleDirectoryListing[i], wpmPath + simpleDirectoryListing[i]);
                    if (doManual)Console.WriteLine("Downloaded file: " + simpleDirectoryListing[i]);
                }
                else if (simpleDirectoryListing[i].Length > 0) if (doManual) Console.WriteLine("This file exists locally, no need to download: " + simpleDirectoryListing[i]);
            }
            ftpClient = null;
            // ==================================================================================================================
            String wpmOut = "";
            String myFile = "";
            // Get the current date as YYYYMMDD
            //DateTime myDate = DateTime.Now;
            //String currDate = myDate.ToString("yyyyMMdd");
            //int PayTotal;
            //String wpmPath = "D:\\qlrepdev\\wpm\\"; // change this path to the actual finance path
            if (doManual) Console.WriteLine("");
            if (doManual) Console.WriteLine("Please type in the date part of your File name or leave blank for todays file");// get the file to process, leave blank for todays file
            if (doManual) Console.WriteLine("e.g. if filename is GL07_Store_Payments_20180102.txt then type in 20180102");
            if (doManual) myFile = Console.ReadLine();
            String wpmF = "";
            //===================================================================================
            String wpmMonth =  DateTime.Now.Month.ToString().PadLeft(2,'0');
            String wpmDay = DateTime.Now.Day.ToString().PadLeft(2, '0');
            String x = DateTime.Now.Year.ToString() + wpmMonth.Substring(wpmMonth.Length - 2) + wpmDay.Substring(wpmMonth.Length - 2);
            //===================================================================================
            String wpmDate = DateTime.Now.ToString("yyyyMMdd");
            wpmF = "GL07_Store_Payments_" + wpmDate + ".txt"; // todays file

            if (myFile.Length > 1) // get the  filename to process, if this is blank then we use todays file, see above
            {
                wpmF = "GL07_Store_Payments_" + myFile.ToString() + ".txt";
            }
            //if (args.Length != 0) // get the filename from the command line.  Decided NOT to use this.
            //{
            //    wpmF = args[0].Trim();
            //}
            StreamWriter writerX;
            if (doManual) Console.WriteLine("File to be processed is: " + wpmF);
            if (doManual) Console.WriteLine(File.Exists(wpmPath + wpmF) ? "File exists." : "File does not exist.");
            if (File.Exists(wpmPath + wpmF))
            {
                using (StreamWriter writer = new StreamWriter(wpmOutputPath + "wpm_" + wpmDate + ".txt", false, Encoding.Unicode))// This is the OUTPUT file
                //using (StreamWriter writer = new StreamWriter("d:\\qlrepdev\\wpm\\wpm.txt", false, Encoding.Unicode))// This is the OUTPUT file
                {
                    using (TextFieldParser tfp = new TextFieldParser(wpmPath + wpmF.ToString()))// + DateTime.Now.ToString("yyyyMMdd") + ".txt"))// This is the SOURCE file.
                    //using (TextFieldParser tfp = new TextFieldParser(@"D:\qlrepdev\wpm\wpmF.ToString()))// + DateTime.Now.ToString("yyyyMMdd") + ".txt"))// This is the SOURCE file.

                    //            using (TextFieldParser tfp = new TextFieldParser(@"d:\qlrepdev\wpm\GL07_Store_Payments_" + DateTime.Now.ToString("yyyyMMdd") + ".txt"))// This is the SOURCE file.
                    {
                        // The TextFieldParser allows us to read a fixed width file and populate a String array based upon the
                        // SetFieldWidths definition.
                        tfp.TextFieldType = FieldType.FixedWidth;
                        tfp.TrimWhiteSpace = false; // Ensure none of the spaces in the fixed width data are truncated.
                        // Below is the fixed width definition as taken from the ABW _GL07_55 file.
                        tfp.SetFieldWidths(new int[] { 25, 25, 25, 2, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 2, 20, 20, 11, 
                    20, 20, 20, 255, 8, 8, 15, 6, 1, 100, 255, 8, 8, 20, 25, 15, 27, 2, 1, 1, 
                    25, 1, 15, 9, 25, 25, 25, 255, 160, 40, 40, 35, 2, 25, 15, 3, 25, 20, 20, 4,
                    2, 2, 13, 11, 15, 2});

                        int i = 0;
                        //PayTotal = 0;
                        //if (true)// for TESTING
                        if (Directory.Exists("\\\\mexico\\datafiles\\data import\\"))
                        {
                            while (!tfp.EndOfData)
                            {

                                i = i + 1; // use this to append to the ext_inv_ref field in order to make that field unique
                                string[] fields = tfp.ReadFields();  // remove any data here as we do not use this data.
                                wpmOut = "\\\\mexico\\datafiles\\data import\\" + fields[0].Trim() + ".txt";
                                //wpmOut = "d:\\" + fields[0].Trim() + ".txt";
                                try
                                {
                                    writerX = new StreamWriter("\\\\mexico\\datafiles\\data import\\" + fields[0].Trim() + ".txt", true, Encoding.Unicode);// This is the OUTPUT file
                                    //writerX = new StreamWriter("D:\\" + fields[0].Trim() + ".txt", true, Encoding.Unicode);// for TESTING

                                    // not using the GL07 class yet.  May do in the future
                                    GL07 fw = new GL07(fields);
                                    //String bid = fw.batch_id;

                                    //fields[29] = ext_inv_ref - this needs to be unique
                                    //fields[5] = Account - this needs to be different for Trade customers.
                                    //fields[39] = apar_type = R if we are a sales ledger line
                                    //fields[40] = apar_id = customerID trade = C101380 which generally has a length of 7; the length > 5 and < 9 and begins with a C
                                    // studentID's generally are 11 characters long.
                                    // Change fields[5] to 21101 if match a trade ID
                                    // change apar_id to blank field 25 in length if apar_type <> R and there is something in the apar_id
                                    // for NON Sales Ledger lines this needs removing.
                                    batchID = fields[0].Trim() + ".TXT";// the .txt appended to batchID means we can use [filename] in the IntellAgent for the batchID in the GL07
                                    fields[0] = batchID.PadRight(25);// rename the batchID field so that we can automate the import in ABW via IntellAgent
                                    //fields[1] = "BA".PadRight(25);// rename the batchID field so that we can automate the import in ABW via IntellAgent
                                    if (fields[5].Trim() == "24301")// This is the bank line.
                                    {
                                        fields[2] = "XX".PadRight(25);// set the voucher type to XX for the bank line only, this ensures that the transaction fails and it will go into the Batch Input maintenance screen
                                                         // Gill can then see all of the transaction lines and amend the bank line to OP so that it will post.
                                    }
                                    if (fields[6].ToUpper().Trim() == "R")
                                    {
                                        //PayTotal = PayTotal + Convert.ToInt32(fields[18]);
                                        fields[6] = "".PadRight(25); // products  CostCentre data for field cat_1 () the remove any data here as we do not use this data.
                                    }
                                    fields[8] = "".PadRight(25); // products dim_3 data for field cat_3 () the remove any data here as we do not use this data.
                                    if (fields[13].ToUpper().Trim() == "SS")
                                    {
                                        fields[13] = "SG".PadRight(25); // Sales TAX from the online store needs setting to SG from SS
                                    }
                                    if (fields[39].ToUpper().Trim() != "R" && fields[40].Trim().Length > 0)
                                    {
                                        fields[40] = "".PadRight(25);// remove the apar_id data for non sales ledger data
                                    }
                                    if (fields[39].ToUpper().Trim() == "R" && fields[40].Trim().Length > 5 && fields[40].Trim().Length < 9 && fields[40].Substring(0, 1).ToUpper() == "C")
                                    {
                                        fields[5] = "21101".PadRight(25);// this is a trade account so change the Account to the trade account 21101
                                    }
                                    if (fields[39].ToUpper().Trim() == "R")
                                    {
                                        String newS = fields[29].Trim() + " ^" + i; // add an extra number onto the end of the order number for Sales Ledger lines.
                                        fields[29] = newS.PadRight(100);// make the ext_inv_ref field unique - this only applys to the ABW test system.
                                    }
                                    // Create a fixed width line from the String array of fixed width values.
                                    //test for a NON bankline and only write NON bank lines - to be done maybe
                                    String newLine = "";
                                    foreach (String field in fields)
                                    {
                                        newLine = newLine + field;
                                    }

                                    writer.WriteLine(newLine);// Write the updated fixed width data to file for local use.
                                    writerX.WriteLine(newLine);// Write the updated fixed width data to file for mexico.
                                    writerX.Close();
                                    writerX.Dispose();  //}//if fileOpen
                                }
                                catch (Exception ex) { Console.WriteLine("ERROR: " + ex.ToString()); }
                            }
                        }
                        else { if (doManual) Console.WriteLine("You do not have access to \\\\MEXICO\\DataFiles\\Data Import"); }
                        tfp.Close();
                        if (File.Exists(wpmOut)) if (doManual) Console.WriteLine(wpmOut + " Successfully created");
                        
                    }

                    //create a new GL bank line for each type
                    // PaymentTotal
                    // BankNonPayLineTotal = BankTotal - PaymentTotal
                    // Write bank line for Payment

                    //Write bank line for NonPayment

                    //-----------------------------------------------------------------------------------------------------------
                    // using the Streamwriter works effectively for our system as we are already dealing with a fixed width format
                    // from the TextFieldParser
                    // This may be useful to write A FIXED WIDTH FILE then look at this link
                    // http://www.blackwasp.co.uk/WriteFixedWidth.aspx



                    writer.Close();
                    //StreamReader sr = new StreamReader("d:\\qlrepdev\\wpm\\wpm.txt");
                    //string s = sr.ReadToEnd();
                    //sr.Close();
                    //writer.Dispose();
                }// end of using
                if (doManual) Console.WriteLine("Press Enter key to continue");
                if (doManual) Console.ReadLine();
            }// end of file test
            else // the file does NOT exist
            {
                if (doManual) Console.WriteLine("Press Enter key to continue");
                if (doManual) Console.ReadLine();

            }

            //FTP stuff
            /* Create Object Instance */
            /* Create Object Instance */
            //ftp ftpClient = new ftp(@" ftp://uk-ftp-1.wpmeducation.com", "WAR0127-01_store_edu_wpmhost_net_download", "yvn?ncLXfK--eO#7");

            /* Upload a File */
            //ftpClient.upload("etc/test.txt", @"C:\Users\metastruct\Desktop\test.txt");

            /* Download a File */
            //ftpClient.download("data_export/GL07_Store_Payments_20180704.txt", @"D:\testMe.txt");

            /* Delete a File */
            //ftpClient.delete("etc/test.txt");

            /* Rename a File */
            //ftpClient.rename("etc/test.txt", "test2.txt");

            /* Create a New Directory */
            //ftpClient.createDirectory("etc/test");

            /* Get the Date/Time a File was Created */
            //string fileDateTime = ftpClient.getFileCreatedDateTime("etc/test.txt");
            //Console.WriteLine(fileDateTime);

            /* Get the Size of a File */
            //string fileSize = ftpClient.getFileSize("etc/test.txt");
            //Console.WriteLine(fileSize);

            /* Get Contents of a Directory (Names Only) */
            //string[] simpleDirectoryListing = ftpClient.directoryListSimple("data_export");
            //for (int i = 0; i < simpleDirectoryListing.Count(); i++)
            //{
            //    Console.WriteLine(simpleDirectoryListing[i]);
            //    if (!File.Exists(simpleDirectoryListing[i]) && simpleDirectoryListing[i].Length > 0)
            //    {
            //        // then download file
            //        ftpClient.download("data_export/" + simpleDirectoryListing[i] , simpleDirectoryListing[i]);

            //    }
            //}

            /* Get Contents of a Directory with Detailed File/Directory Info */
            //string[] detailDirectoryListing = ftpClient.directoryListDetailed("/data_export");
            //for (int i = 0; i < detailDirectoryListing.Count(); i++) { Console.WriteLine(detailDirectoryListing[i]); }
            ///* Release Resources */
            //ftpClient = null;
        }

    }

}
