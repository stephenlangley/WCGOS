﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPM
{
    class GL07
    {
        public String batch_id, myinterface, voucher_type, trans_type, client, account, dim_1, dim_2, dim_3, dim_4, 
            dim_5, dim_6, dim_7, tax_code, tax_system, currency, dc_flag, cur_amount, amount, number_1, 
            value_1, value_2, value_3, description, trans_date, voucher_date, voucher_no, period, tax_flag, ext_inv_ref, 
            ext_ref, due_date, disc_date, discount, commitment, order_id, kid, pay_transfer, status, apar_type, 
            apar_id, pay_flag, voucher_ref, sequence_ref, intrule_id, factor_short, responsible, apar_name, address, province, 
            place, bank_account, pay_method, vat_reg_no, zip_code, curr_licence, account2, base_amount, base_curr, pay_temp_id, 
            allocation_key, period_no, clearing_code, swift, arrive_id, bank_acc_type
        ;

        public GL07(String[] fields)
        {
            // Need to set out the GL07 schema here
            // may use a structure or a name value pairing
            batch_id = fields[0];
            myinterface = fields[1];
            voucher_type = fields[2];
            trans_type = fields[3];
            client = fields[4];
            account = fields[5];
            dim_1 = fields[6];
            dim_2 = fields[7];
            dim_3 = fields[8];
 
            dim_4 = fields[9];
            dim_5 = fields[10];
            dim_6 = fields[11];
            dim_7 = fields[12];
            tax_code = fields[13];
            tax_system = fields[14];
            currency = fields[15];
            dc_flag = fields[16];
            cur_amount = fields[17];
            amount = fields[18];

            number_1 = fields[19];
            value_1 = fields[20];
            value_2 = fields[21];
            value_3 = fields[22];
            description = fields[23];
            trans_date = fields[24];
            voucher_date = fields[25];
            voucher_no = fields[26];
            period = fields[27];
            tax_flag = fields[28];
            ext_inv_ref = fields[29];
            ext_ref = fields[30];

            due_date = fields[31];
            disc_date = fields[32];
            discount = fields[33];
            commitment = fields[34];
            order_id = fields[35];
            kid = fields[36];
            pay_transfer = fields[37];
            status = fields[38];
            apar_type = fields[39];
            apar_id = fields[40];

            pay_flag = fields[41];
            voucher_ref = fields[42];
            sequence_ref = fields[43];
            intrule_id = fields[44];
            factor_short = fields[45];
            responsible = fields[46];
            apar_name = fields[47];
            address = fields[48];
            province = fields[49];
            place = fields[50];

            bank_account = fields[51];
            pay_method = fields[52];
            vat_reg_no = fields[53];
            zip_code = fields[54];
            curr_licence = fields[55];
            account2 = fields[56];
            base_amount = fields[57];
            base_curr = fields[58];
            pay_temp_id = fields[59];
            allocation_key = fields[60];

            period_no = fields[61];
            clearing_code = fields[62];
            swift = fields[63];
            arrive_id = fields[64];
            bank_acc_type = fields[65];

        }
    }
}
